<!DOCTYPE html>
<html lang="ru-RU">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>IAS</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="css/datatables.min.css"/>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body class="has_message inner_page">

<!-- message box -->
<div class="message_box">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="message_content">
					<div class="message_text">Пілотний модуль планування заходів державного нагляду (контролю) для запуску ІАС </div>
					<button class="message_close icon-cancel"></button>
				</div>
			</div>
		</div>
	</div>
</div>

<button href="#" class="faq_button_mobile visible-xs" data-toggle="modal" data-target="#faq_modal">?</button>


<!-- header -->
<nav class="navbar_box">
	<div class="container">
		<div class="row">
			<div class="col-xs-9 col-lg-3">
				<div class="logo_box">
					<a href="#"><img src="img/logo.png" srcset="img/logo@2x.png 2x" width="256" height="34"></a>
				</div>
			</div>
			<div class="col-xs-3 hidden-lg">
				<div class="navbar-header">
					<button type="button" class="open_main_menu" data-toggle="collapse" data-target="#w0-collapse">
						<span class="lines"></span>
					</button>
				</div>
			</div>
			<div class="col-lg-9 col-xs-12">

				<!--desktop menu-->
				<ul id="w2" class="navbar-nav nav desktop_nav desktop-menu">
					<li><a href="#"><span>Контролюючі органи</span></a></li>
					<li class="dropdown">
						<a class="dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false"><span>Довідкова інформація</span></a>
						<ul id="w3" class="dropdown-menu">
							<li><a href="#"><span>Законодавство</span></a></li>
							<li><a href="#"><span>Форми актів перевірки</span></a></li>
							<li><a href="#"><span>Критерії ризику</span></a></li>
						</ul>
					</li>
					<li><a href="#"><span>Комплексний план</span></a></li>
					<li class="dropdown">
						<a class="dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false"><span>Перевірки</span></a>
						<ul id="w4" class="dropdown-menu">
							<li><a href="#"><span>Результати планових перевірок</span></a></li>
							<li><a href="#"><span>Результати позапланових перевірок</span></a></li>
							<li><a href="#"><span>Загальні результати</span></a></li>
						</ul>
					</li>
					<li><a href="#"><span>Вхід для співробітників</span></a></li>
				</ul>

				<!--mobile menu-->
				<ul class="navbar-nav nav mobile_nav">
					<li><a href="#">Контролюючі органи</a></li>
					<li class="has_child">
						<a href="#">Довідкова інформація</a>
						<ul class="mobile_submenu">
							<li><a href="#">повернутися до загального меню </a></li>
							<li><a href="#">Довідкова інформація</a></li>
							<li><a href="#">Законодавство</a></li>
							<li><a href="#">Форми актів перевірки</a></li>
							<li><a href="#">Критерії ризику</a></li>
						</ul>
					</li>
					<li><a href="#">Комплексний план</a></li>
					<li class="has_child">
						<a href="#" >Перевірки</a>
						<ul class="mobile_submenu">
							<li><a href="#">повернутися до загального меню </a></li>
							<li><a href="#">Перевірки</a></li>
							<li><a href="#">Результати планових перевірок</a></li>
							<li><a href="#">Результати позапланових перевірок</a></li>
							<li><a href="#">Загальні результати</a></li>
						</ul>
					</li>
					<li><a href="#">Вхід для співробітників</a></li>
				</ul>
			</div>
		</div>
	</div>
</nav>

<section class="tabs_section">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<ul class="nav nav-tabs control_tabs">
					<li class="nav-item active">
						<a class="nav-link" data-toggle="tab" href="#nav_tab1">Подання звітності</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#nav_tab2">Планові перевірки (загальні дані)</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#nav_tab3">Планові перевірки (порушення)</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#nav_tab4">Позапланові перевірки (загальні дані)</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#nav_tab5">Позапланові перевірки (порушення)</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>


<section class="page_section">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="page_header">
					<h1 class="page_title">Планові перевірки (загальні дані)</h1>
				</div>
			</div>
			<div class="col-xs-12">

				<ul class="nav nav-tabs employees_tabs">
					<li class="nav-item active">
						<a class="nav-link active" data-toggle="tab" href="#tab1" aria-expanded="true">За 2017 рік</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#tab2" aria-expanded="false">За 2018 рік (наповнюється)</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#tab2" aria-expanded="false">За 2018 рік (наповнюється)</a>
					</li>
				</ul>

				<div class="tab-content">
					<div class="tab-pane fade active in" id="tab1">

						<table class="table table-striped table-bordered data_table">
							<thead>
							<tr>
								<th><a href="#">#</a></th>
								<th><a href="#">Найменування суб’єкта господарювання</a></th>
								<th><a href="#">Ідентифікаційний код юридичної особи або реєстраційний номер облікової картки платника податків фізичної особи - підприємця</a></th>
								<th><a href="#">Місце провадження господарської діяльності суб'єкта господарювання або його відокремлених підрозділів</a></th>
								<th><a href="#">Предмет здійснення заходу державного нагляду (контролю) </a></th>
								<th><a href="#">Ступінь ризику</a></th>
								<th><a href="#">Стан перевірки</a></th>
								<th><a href="#">Підстава непроведення заходу державного нагляду (контролю)</a></th>
								<th><a href="#">Дата початку періоду діяльності, що охоплюється перевіркою</a></th>
							</tr>
							<tr>
								<td></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
							</tr>
							</thead>
							<tbody>
							<tr>
								<td>1</td>
								<td><a href="#">ТОВ "ОСТЕР"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							<tr>
								<td>2</td>
								<td><a href="#">ТОВ "ОСТЕР"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							<tr>
								<td>3</td>
								<td><a href="#">ТОВ "ХМІЛЬНИКАГРОТЕХСЕРВІС"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							<tr>
								<td>4</td>
								<td><a href="#">ТОВ "ХМІЛЬНИКАГРОТЕХСЕРВІС"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							<tr>
								<td>5</td>
								<td><a href="#">ТОВ "ХМІЛЬНИКАГРОТЕХСЕРВІС"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							<tr>
								<td>15</td>
								<td><a href="#">ТОВ "ХМІЛЬНИКАГРОТЕХСЕРВІС"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							</tbody>
						</table>
						<ul class="pagination visible-lg">
							<li class="prev disabled"><span><i class="icon-angle-left"></i></span></li>
							<li class="active"><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li><a href="#">6</a></li>
							<li><span>...</span></li>
							<li><a href="#">10</a></li>
							<li class="next"><a href="#" data-page="1"><i class="icon-angle-right"></i></a></li>
						</ul>
					</div>

					<div class="tab-pane fade" id="tab2">

						<table class="table table-striped table-bordered data_table">
							<thead>
							<tr>
								<th><a href="#">#</a></th>
								<th><a href="#">Найменування суб’єкта господарювання</a></th>
								<th><a href="#">Ідентифікаційний код юридичної особи або реєстраційний номер облікової картки платника податків фізичної особи - підприємця</a></th>
								<th><a href="#">Місце провадження господарської діяльності суб'єкта господарювання або його відокремлених підрозділів</a></th>
								<th><a href="#">Предмет здійснення заходу державного нагляду (контролю) </a></th>
								<th><a href="#">Ступінь ризику</a></th>
								<th><a href="#">Стан перевірки</a></th>
								<th><a href="#">Підстава непроведення заходу державного нагляду (контролю)</a></th>
								<th><a href="#">Дата початку періоду діяльності, що охоплюється перевіркою</a></th>
							</tr>
							<tr>
								<td></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
								<td><input type="text" class="form-control" name=""></td>
							</tr>
							</thead>
							<tbody>
							<tr>
								<td>1</td>
								<td><a href="#">ТОВ "ОСТЕР"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							<tr>
								<td>2</td>
								<td><a href="#">ТОВ "ОСТЕР"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							<tr>
								<td>3</td>
								<td><a href="#">ТОВ "ХМІЛЬНИКАГРОТЕХСЕРВІС"</a></td>
								<td>23103085</td>
								<td>м. Вінниця, вул. Артема 7</td>
								<td>перевірка</td>
								<td>високий</td>
								<td>проведено</td>
								<td>не проведено у зв'язку, що листом суб'єкт господарювання просить перенести строк перевірки (директор на лікарняному)</td>
								<td>14.06.2017</td>
							</tr>
							</tbody>
						</table>
						<ul class="pagination visible-lg">
							<li class="prev disabled"><span><i class="icon-angle-left"></i></span></li>
							<li class="active"><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li><a href="#">6</a></li>
							<li><span>...</span></li>
							<li><a href="#">10</a></li>
							<li class="next"><a href="#" data-page="1"><i class="icon-angle-right"></i></a></li>
						</ul>
					</div>

			</div>

			</div>
		</div>
	</div>
</section>

<!-- news_filter_modal -->
<div class="modal fade" id="news_filter_modal" tabindex="-1" role="dialog" aria-labelledby="faq_modal" aria-hidden="true">
	<div class="modal-dialog small_modal">
		<button class="close_modal icon-cancel" data-dismiss="modal" aria-label="Close"></button>

		<div class="modal_filter">
			<h2 class="modal_title">Фільтр запиту</h2>
			<form action="/">
				<div class="form-group">
					<label class="control-label" for="doc_name">Назва</label>
					<input type="text" id="doc_name" class="form-control" name="">
				</div>
				<div class="form-group">
					<label class="control-label" for="doc_name">Коротка назва</label>
					<input type="text" class="form-control" name="">
				</div>
				<div class="form-group">
					<label class="control-label" for="doc_name">Код</label>
					<input type="text" class="form-control" name="">
				</div>
				<div class="form-group">
					<label class="control-label" for="doc_name">Адреса</label>
					<input type="text" class="form-control" name="">
				</div>
				<div class="form-group">
					<label class="control-label" for="doc_name">Директор</label>
					<input type="text" class="form-control" name="">
				</div>
				<div class="form-group">
					<label class="control-label" for="doc_name">Статус</label>
					<input type="text" class="form-control" name="">
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-primary modal_submit">Фільтрувати</button>
				</div>
			</form>
		</div>
	</div>
</div>


<!--sponsors-->
<section class="sponsors">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-3 col-md-4">
				<a href="http://drs.gov.ua/" target="_blank">
					<img src="img/drs.png" srcset="img/drs@2x.png 2x,		 img/drs@3x.png 3x" alt="Державна регуляторна служба України" class="img-responsive">
				</a>
			</div>
			<div class="col-xs-12 col-sm-5 col-md-4">
				<a href="http://me.gov.ua/" target="_blank">
					<img src="img/sponsor2.png" srcset="img/sponsor2@2x.png 2x, img/sponsor2@3x.png 3x" alt="Міністерство економічного розвитку і торгівлі України" class="img-responsive center-block">
				</a>
			</div>
			<div class="col-xs-12 col-sm-4">
				<a href="http://brdo.com.ua" target="_blank">
					<img src="img/sponsor3.png" srcset="img/sponsor3@2x.png 2x, img/sponsor3@3x.png 3x" alt="Офіс ефективного регулювання" class="img-responsive pull-right">
				</a>
			</div>
		</div>
	</div>
</section>

<!-- footer -->
<footer id="footer">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-6 col-sm-push-6">
				<div class="footer_contacts">
					<span class="icon-mail-alt"><a href="mailto:ias@brdo.com.ua ">ias@brdo.com.ua </a></span>
					<span class="icon-phonebook"><a href="tel:+38 (093) 564 18 43 ">+38 (093) 564 18 43 </a></span>
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-sm-pull-6">
				<p class="copyright">© Офіс ефективного регулювання (BRDO) 2017</p>
			</div>
		</div>
	</div>
</footer>


<!-- faq_modal -->
<div class="modal fade" id="faq_modal" tabindex="-1" role="dialog" aria-labelledby="faq_modal" aria-hidden="true">
	<div class="modal-dialog">
		<button class="close_modal icon-cancel" data-dismiss="modal" aria-label="Close"></button>
		<div class="faq_modal_content">
			<ul class="faq_nav">
				<li class="active"><a href="#tab1" data-toggle="tab" class="icon-home-1"></a></li>
				<li><a href="#tab2" data-toggle="tab" class="icon-chart"></a></li>
				<li><a href="#tab3" data-toggle="tab" class="icon-phonebook"></a></li>
				<li><a href="#tab4" data-toggle="tab" class="icon-profile"></a></li>
			</ul>
			<div class="tab-content">
				<div class="tab-pane active  in" id="tab1">
					<div class="faq_modal_image_wrap">
						<img src="img/faq_img.png" alt="">
					</div>
					<div class="faq_modal_text">
						<div class="faq_modal_text_inner">
							<h2 class="modal_title">Контролюючі органи</h2>
							<p>Дозволяє переглянути перелік органів, їх документи, затверджені річні плани, а також контактні дані посадових осіб, відповідальних за узгодження дат комплексних заходів державного нагляду (контролю).</p>

							<p>Після остаточного затвердження комплексного плану, Ви можете вносити зміни у свої проекти річних планів (поза системою), за виключенням дій, що можуть спричинити наявність розбіжностей з комплексним планом. Такими діями є: - додавання нових суб'єктів до переліку суб'єктів, що підлягають перевірці у наступному плановому періоді; - зміна будь-якої інформації стосовно заходів державного нагляду (контролю) щодо суб'єктів господарювання, які потрапили у план комплексних заходів.</p>
							<p>	Вам необхідно завантажити затверджений річний план Вашого органу ДО 1 грудня 2017 року.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane " id="tab2">
					<div class="faq_modal_image_wrap">
						<img src="img/bg1.jpg" alt="">
					</div>
					<div class="faq_modal_text">
						<div class="faq_modal_text_inner">
							<h2 class="modal_title">Довідково</h2>
							<p>Дозволяє переглянути перелік органів, їх документи, затверджені річні плани, а також контактні дані посадових осіб, відповідальних за узгодження дат комплексних заходів державного нагляду (контролю).</p>
							<p>	Вам необхідно завантажити затверджений річний план Вашого органу ДО 1 грудня 2017 року.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane " id="tab3">
					<div class="faq_modal_image_wrap">
						<img src="img/faq_img.png" alt="">
					</div>
					<div class="faq_modal_text">
						<div class="faq_modal_text_inner">
							<h2 class="modal_title">Законодавство</h2>
							<p>Дозволяє переглянути перелік органів, їх документи, затверджені річні плани, а також контактні дані посадових осіб, відповідальних за узгодження дат комплексних заходів державного нагляду (контролю).</p>
							<p>	Вам необхідно завантажити затверджений річний план Вашого органу ДО 1 грудня 2017 року.</p>
							<p>	Вам необхідно завантажити затверджений річний план Вашого органу ДО 1 грудня 2017 року.</p>
						</div>
					</div>

				</div>
				<div class="tab-pane " id="tab4">
					<div class="faq_modal_image_wrap">
						<img src="img/faq_img.png" alt="">
					</div>
					<div class="faq_modal_text">
						<div class="faq_modal_text_inner">
							<h2 class="modal_title">Контролюючі органи</h2>
							<p>Дозволяє переглянути перелік органів, їх документи, затверджені річні плани, а також контактні дані посадових осіб, відповідальних за узгодження дат комплексних заходів державного нагляду (контролю).</p>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<script type='text/javascript' src="js/bootstrap.min.js"></script>
<script type='text/javascript' src="js/ion.rangeSlider.min.js"></script>
<script type='text/javascript' src="js/sticky-kit.min.js"></script>
<script type='text/javascript' src="js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="js/datatables.min.js"></script>
<script type="text/javascript" src="js/fixedColumns.bootstrap.min.js"></script>
<script type='text/javascript' src="js/script.js"></script>
</body>
</html>